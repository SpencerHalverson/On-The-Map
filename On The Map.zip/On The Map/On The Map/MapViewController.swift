//
//  MapViewController.swift
//  On The Map
//
//  Created by Spencer Halverson on 4/22/16.
//  Copyright © 2016 Bodypursuit.com. All rights reserved.
//

import Foundation
import MapKit
import CoreLocation
import UIKit
import SafariServices

class MapViewController: UIViewController, MKMapViewDelegate, SFSafariViewControllerDelegate {
    
    var appDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
    
    @IBOutlet weak var studentMapView: MKMapView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        studentMapView.delegate = self
        getStudents()
        parentViewController!.navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .Refresh, target: self, action: "refreshMap")
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    func refreshMap(){
        studentMapView.removeAnnotations(Students.annotationsArray)
        Students.studentsArray.removeAll()
        Students.annotationsArray.removeAll()
        getStudents()
    }

    func convertStudentInfo(student: StudentInformation) {
        let annotation = MKPointAnnotation()
        if let latitude = student.lat, let longitude = student.lon, let firstName = student.firstName,
        let lastName = student.lastName, let url = student.mediaUrl{
            annotation.coordinate.latitude = latitude
            annotation.coordinate.longitude = longitude
            annotation.title = firstName + " " + lastName
            annotation.subtitle = url
        }
        Students.annotationsArray.append(annotation)
        
    }
    
    func getStudents(){
        ParseApiMethods.getStudents() {(success, studentInfo, errorString) in
            performUIUpdatesOnMain(){
                if success{
                    self.convertStudentInfo(studentInfo!)
                    self.studentMapView.addAnnotations(Students.annotationsArray)
                }else{
                    self.displayAlert(errorString!)
                }
            }
        }
    }
    
    
    func mapView(mapView: MKMapView, viewForAnnotation annotation: MKAnnotation) -> MKAnnotationView? {
        var view = mapView.dequeueReusableAnnotationViewWithIdentifier("pin") as? MKPinAnnotationView
        view?.userInteractionEnabled = true
        if view == nil{
            view = MKPinAnnotationView(annotation: annotation, reuseIdentifier: "pin")
            view!.animatesDrop = false
            view!.canShowCallout = true
        }else{
            view!.annotation = annotation
        }
        return view
    }
    
    func mapView(mapView: MKMapView, didSelectAnnotationView view: MKAnnotationView) {
        view.canShowCallout = true
        view.rightCalloutAccessoryView = UIButton(type: .DetailDisclosure)
    }
    
    func mapView(mapView: MKMapView, annotationView view: MKAnnotationView, calloutAccessoryControlTapped control: UIControl) {
        if let urlString = view.annotation?.subtitle!{
            if let url = NSURL(string: urlString){
                if UIApplication.sharedApplication().canOpenURL(url){
                    let safariVC = SFSafariViewController(URL: url)
                    safariVC.delegate = self
                    presentViewController(safariVC, animated: true, completion: nil)
                }else{
                    displayAlert("Invalid URL")
                }
            }else{
                displayAlert("Invalid URL")
            }
        }
        
    }
    
    func displayAlert(message: String){
        let alertVC = UIAlertController.init(title: "Download Failed", message: message, preferredStyle: UIAlertControllerStyle.Alert)
        let okAction = UIAlertAction(title: "Try Again", style: .Cancel) {(action) in
        }
        alertVC.addAction(okAction)
        presentViewController(alertVC, animated: true, completion: nil)
    }

}