//
//  ParseApiMethods.swift
//  On The Map
//
//  Created by Spencer Halverson on 4/29/16.
//  Copyright © 2016 Bodypursuit.com. All rights reserved.
//

import Foundation
import MapKit
import CoreLocation
import UIKit

class ParseApiMethods {
    
    static var appDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
    
    static func getStudents(completionHandler: (success: Bool, studentInfo: StudentInformation?, errorString: String?) ->  Void) {
        
        let request = NSMutableURLRequest(URL: NSURL(string: "https://api.parse.com/1/classes/StudentLocation?limit=100&order=-updatedAt")!)
        request.addValue("QrX47CA9cyuGewLdsL7o5Eb8iug6Em8ye0dnAbIr", forHTTPHeaderField: "X-Parse-Application-Id")
        request.addValue("QuWThTdiRmTux3YaDseUSEpUKo7aBYM737yKd4gY", forHTTPHeaderField: "X-Parse-REST-API-Key")
        
        let session = NSURLSession.sharedSession()
        let task = session.dataTaskWithRequest(request) { (data, response, error) in
            
            if error != nil{
                completionHandler(success: false, studentInfo: nil,errorString: "Unable to process download!")
                return
            } else {
                guard let data = data else{
                    completionHandler(success: false, studentInfo: nil, errorString: "There are no student locations!")
                    print("There is no data")
                    return
                }
                
                let parsedResult: AnyObject!
                do{
                    parsedResult = try NSJSONSerialization.JSONObjectWithData(data, options: .AllowFragments)
                }catch{
                    print("Could not parse data")
                    return
                }
                
                guard let students = parsedResult["results"] as? [[String: AnyObject]] else{
                    completionHandler(success: false, studentInfo: nil, errorString: "No results to display")
                    print("Parsed results empty")
                    return
                }
                
                for student in students{
                    let latitude = student["latitude"] as! Double
                    let longitude = student["longitude"] as! Double
                    let firstName = student["firstName"] as! String
                    let lastName = student["lastName"] as! String
                    let url = student["mediaURL"] as! String
                    
                    let studentInfo = StudentInformation(firstName: firstName, lastName: lastName, mediaUrl: url, lat: latitude, lon: longitude, studentDict: student)
                    Students.studentsArray.append(studentInfo)
                    completionHandler(success: true ,studentInfo: studentInfo, errorString: nil)
                }
            }
        }
        task.resume()
    }
    
    static func postStudentLocation(lat: Double, lon: Double, mapString: String, url: String,completionHandler: (success: Bool, errorString: String?) -> Void){
        
        let userId = appDelegate.userId
        let userInfo = appDelegate.userInfo
        
        let request = NSMutableURLRequest(URL: NSURL(string: "https://api.parse.com/1/classes/StudentLocation")!)
        request.addValue("QrX47CA9cyuGewLdsL7o5Eb8iug6Em8ye0dnAbIr", forHTTPHeaderField: "X-Parse-Application-Id")
        request.addValue("QuWThTdiRmTux3YaDseUSEpUKo7aBYM737yKd4gY", forHTTPHeaderField: "X-Parse-REST-API-Key")
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.HTTPMethod = "POST"
        
        guard let first = userInfo.firstName, let last = userInfo.lastName else{
            return
        }
        
        var jsonBody: [String:AnyObject]!
        jsonBody = [ "uniqueKey":userId!,"firstName":first,"lastName":last,"mapString":mapString,"mediaURL":url,"latitude":lat,"longitude":lon]
        
        do{
            request.HTTPBody = try! NSJSONSerialization.dataWithJSONObject(jsonBody, options: .PrettyPrinted)
        }
        
        let session = NSURLSession.sharedSession()
        let task = session.dataTaskWithRequest(request) {(data, response, error) in
            if error != nil{
                completionHandler(success: false, errorString: "There was an error with the network")
                return
            }else{
                
                guard let data = data else{
                    return
                }
                
                guard let statusCode = (response as? NSHTTPURLResponse)?.statusCode  else {
                    completionHandler(success: false, errorString: "Could not post location to network")
                    return
                }
                
                guard let response = response else{
                    return
                }
                
                if statusCode >= 200 && statusCode <= 299{
                    completionHandler(success: true, errorString: nil)
                }
                
                print(response)
                print("this is the status code" + "\(statusCode)")
                
                print(NSString(data: data, encoding: NSUTF8StringEncoding))
                
            }
            
        }
        task.resume()
    }
    
}