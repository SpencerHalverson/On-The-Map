//
//  TabBarController.swift
//  On The Map
//
//  Created by Spencer Halverson on 4/23/16.
//  Copyright © 2016 Bodypursuit.com. All rights reserved.
//

import Foundation
import UIKit

class TabBarController: UITabBarController {
    
    @IBAction func logout(sender: UIBarButtonItem) {
        let alertVC = UIAlertController(title: "Log Out", message: "Are you sure?", preferredStyle: .Alert)
        let yes = UIAlertAction(title: "Yes", style: .Default) {(action) in
            self.secureLogout()
        }
        alertVC.addAction(yes)
        
        let no = UIAlertAction(title: "No", style: .Cancel) {(action) in
        }
        alertVC.addAction(no)
        presentViewController(alertVC, animated: true, completion: nil)
    }
    
    func  displayError(message: String) {
        let alertVC = UIAlertController(title: "Logout Failed", message: message, preferredStyle: .Alert)
        let okAction = UIAlertAction(title: "Ok", style: .Cancel) {(action) in
        }
        alertVC.addAction(okAction)
        presentViewController(alertVC, animated: true, completion: nil)
    }
    
    func secureLogout(){
        UdacityApiMethods.secureLogout() {(success, errorString) in
            performUIUpdatesOnMain(){
                if success{
                    self.dismissViewControllerAnimated(true, completion: nil)
                }else{
                    self.displayError(errorString!)
                }
            }
        }
    }
}