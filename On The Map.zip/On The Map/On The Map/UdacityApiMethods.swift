//
//  UdacityApiMethods.swift
//  On The Map
//
//  Created by Spencer Halverson on 4/27/16.
//  Copyright © 2016 Bodypursuit.com. All rights reserved.
//

import Foundation
import UIKit
import MapKit

class UdacityApiMethods {
    
    static var appDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
        
    static func login(email: String, password: String, completionHandler: (success: Bool, errorString: String?) -> Void){
        
        let request = NSMutableURLRequest(URL: NSURL(string: "https://www.udacity.com/api/session")!)
        request.HTTPMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.HTTPBody = "{\"udacity\": {\"username\": \"\(email)\", \"password\": \"\(password)\"}}".dataUsingEncoding(NSUTF8StringEncoding)
        
        let session = NSURLSession.sharedSession()
        let task = session.dataTaskWithRequest(request) { (data, response, error) in
            
            if error != nil {
                let message = "Login Failed Network Error"
                completionHandler(success: false, errorString: message)
            }else{
                
                guard let statusCode = (response as? NSHTTPURLResponse)?.statusCode where statusCode >= 200 && statusCode <= 299 else {
                    let message = "Incorrect Username or Password"
                    completionHandler(success: false, errorString: message)
                    return
                }
                
                guard let data = data else{
                    return
                }
                
                let newData = data.subdataWithRange(NSMakeRange(5, data.length - 5))
                print(NSString(data: data, encoding: NSUTF8StringEncoding))
                
                var parsedResult: AnyObject!
                do {
                    parsedResult = try NSJSONSerialization.JSONObjectWithData(newData, options: .AllowFragments)
                }catch{
                    let message = "Unable to retrieve parsed result"
                    completionHandler(success: false, errorString: message)
                }
                
                guard let sessionDict = parsedResult["session"] as? [String:AnyObject] else{
                    return
                }
                
                guard let accountDict = parsedResult["account"] as? [String:AnyObject] else{
                    return
                }
                
                if let sessionId = sessionDict["id"] as? String{
                    print(sessionId)
                    self.appDelegate.sessionId = sessionId
                }
                
                if let userId = accountDict["key"] as? String{
                    self.appDelegate.userId = userId
                    getUserData(userId) {(success, userDict, errorString) in
                        if success {
                            guard let userDict = userDict else{
                                return
                            }
                            if let firstName = userDict["first_name"] as? String, let lastName = userDict["last_name"] as? String{
                                let userInfo = UserInfo(firstName: firstName, lastName: lastName)
                                self.appDelegate.userInfo = userInfo
                                print(userInfo)
                            }
                            completionHandler(success: success, errorString: errorString)
                        }else{
                            completionHandler(success: success, errorString: errorString)
                        }
                    }
                    
                    print("USER ID KEY IS" + "\(userId)")
                }
            }
        }
        task.resume()

    }
    
    static func getUserData(id: String, completionHandler: (success: Bool, userDict: [String:AnyObject]?, errorString: String?) -> Void) {
        let request = NSMutableURLRequest(URL: NSURL(string: "https://www.udacity.com/api/users/\(id)")!)
        let session = NSURLSession.sharedSession()
        let task = session.dataTaskWithRequest(request) { data, response, error in
            if error != nil {
                completionHandler(success: false, userDict: nil, errorString: "No User Data")
                return
            }
            
            guard let data = data else{
                return
            }
            
            let newData = data.subdataWithRange(NSMakeRange(5, data.length - 5))
            
            var parsedResult: AnyObject!
            do {
                parsedResult = try NSJSONSerialization.JSONObjectWithData(newData, options: .AllowFragments)
            }catch{
                completionHandler(success: false, userDict: nil, errorString: "Unable to parse data")
            }
            
            guard let userDict = parsedResult["user"] as? [String:AnyObject] else{
                return
            }
            
            completionHandler(success: true, userDict: userDict, errorString: nil)
            
            
        }
        task.resume()
    }
    
    static func secureLogout(completionHandler: (success: Bool, errorString: String?) -> Void){
        let request = NSMutableURLRequest(URL: NSURL(string: "https://www.udacity.com/api/session")!)
        request.HTTPMethod = "Delete"
        var xsrfCookie: NSHTTPCookie? = nil
        let sharedCookieStorage = NSHTTPCookieStorage.sharedHTTPCookieStorage()
        for cookie in sharedCookieStorage.cookies! {
            if cookie.name == "XSRF-TOKEN" {
                xsrfCookie = cookie
            }
        }
        
        if let xsrfCookie = xsrfCookie{
            request.setValue(xsrfCookie.value, forHTTPHeaderField: "X-XSRF-TOKEN")
        }
        
        let session = NSURLSession.sharedSession()
        let task = session.dataTaskWithRequest(request) {(data, response, error) in
            if error != nil{
                completionHandler(success: false, errorString: "Network Connection Issue")
                return
            }else{
                guard let statusCode = (response as? NSHTTPURLResponse)?.statusCode where statusCode >= 200 && statusCode <= 299 else {
                    completionHandler(success: false, errorString: "Network Connection Issue")
                    return
                }
                
                guard let data = data else {
                    return
                }
                
                let newData = data.subdataWithRange(NSMakeRange(5, data.length - 5))
                completionHandler(success: true, errorString: nil)
                
                print(NSString(data: newData, encoding: NSUTF8StringEncoding))
            }
        }
        task.resume()
        
    }


}