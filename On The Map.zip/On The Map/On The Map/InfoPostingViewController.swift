//
//  InfoPostingViewController.swift
//  On The Map
//
//  Created by Spencer Halverson on 4/23/16.
//  Copyright © 2016 Bodypursuit.com. All rights reserved.
//

import Foundation
import UIKit
import CoreLocation
import MapKit

class InfoPostingViewController: UIViewController, MKMapViewDelegate{
    
    var appDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
    
    @IBOutlet weak var findButton: UIButton!
    @IBOutlet weak var addLocationView: UIView!
    @IBOutlet weak var urlTextField: UITextField!
    @IBOutlet weak var mapView: MKMapView!
    @IBOutlet weak var textField: UITextField!
    @IBOutlet weak var submitButton: UIButton!
    @IBOutlet weak var indicator: UIActivityIndicatorView!
    
    var userInfo: UserInfo!
    var userId: String!
    var annotation:MKAnnotation!
    var localSearchRequest:MKLocalSearchRequest!
    var localSearch:MKLocalSearch!
    var localSearchResponse:MKLocalSearchResponse!
    var error:NSError!
    var pointAnnotation:MKPointAnnotation!
    var pinAnnotationView:MKPinAnnotationView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        indicator.stopAnimating()
        userInfo = appDelegate.userInfo
        userId = appDelegate.userId
        
    }
    
    @IBAction func hideUrlKeyboard(sender: UITextField) {
        sender.resignFirstResponder()
    }
    @IBAction func hideLocationKeyboard(sender: UITextField) {
        sender.resignFirstResponder()
    }
    
    @IBAction func findLocation(sender: UIButton) {
        indicator.startAnimating()
        if !textField.text!.isEmpty{
            performUIUpdatesOnMain(){
                self.findStudentLocation()
            }
        }else{
            displayAlert("Please enter valid location.")
        }
    }
    
    func findStudentLocation(){
        if !textField.text!.isEmpty{
            
            if self.mapView.annotations.count != 0{
                annotation = self.mapView.annotations[0]
                self.mapView.removeAnnotation(annotation)
            }
            
            localSearchRequest = MKLocalSearchRequest()
            localSearchRequest.naturalLanguageQuery = textField.text
            localSearch = MKLocalSearch(request: localSearchRequest)
            localSearch.startWithCompletionHandler { (localSearchResponse, error) -> Void in
                
                if localSearchResponse == nil{
                    let alertController = UIAlertController(title: nil, message: "Place Not Found", preferredStyle: UIAlertControllerStyle.Alert)
                    alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.Default, handler: nil))
                    self.presentViewController(alertController, animated: true, completion: nil)
                    return
                }else{
                    
                    self.pointAnnotation = MKPointAnnotation()
                    self.pointAnnotation.title = self.textField.text
                    self.pointAnnotation.coordinate = CLLocationCoordinate2D(latitude: localSearchResponse!.boundingRegion.center.latitude, longitude: localSearchResponse!.boundingRegion.center.longitude)
                    
                    
                    self.pinAnnotationView = MKPinAnnotationView(annotation: self.pointAnnotation, reuseIdentifier: nil)
                    self.mapView.centerCoordinate = self.pointAnnotation.coordinate
                    self.mapView.addAnnotation(self.pinAnnotationView.annotation!)
                    
                    self.indicator.stopAnimating()
                    self.addLocationView.hidden = true
                }
            }
        }else{
            displayAlert("Please enter valid location.")
        }
    }
    
    @IBAction func cancelPost(sender: UIBarButtonItem) {
        self.dismissViewControllerAnimated(true, completion: nil)
    }
    
    @IBAction func postLink(sender: UIButton) {
        if !urlTextField.text!.isEmpty{
            indicator.startAnimating()
            urlTextField.resignFirstResponder()
            let lat = pointAnnotation.coordinate.latitude
            let lon = pointAnnotation.coordinate.longitude
            
            ParseApiMethods.postStudentLocation(lat, lon: lon, mapString: textField.text!, url: urlTextField.text!) {(success, errorString) in
                performUIUpdatesOnMain(){
                    if success{
                        self.indicator.stopAnimating()
                        self.setUIEnabled(true)
                        self.dismissViewControllerAnimated(true, completion: nil)
                    }else{
                        self.displayAlert(errorString!)
                    }
                }
            }
        }else{
            displayAlert("Enter a valid link")
        }
    }
}

extension InfoPostingViewController{
    
    func displayAlert(message: String){
        let alertVC = UIAlertController.init(title: "Post Failed", message: message, preferredStyle: UIAlertControllerStyle.Alert)
        let okAction = UIAlertAction(title: "Try Again", style: .Cancel) {(action) in
            self.indicator.stopAnimating()
            self.setUIEnabled(true)
        }
        alertVC.addAction(okAction)
        presentViewController(alertVC, animated: true, completion: nil)
    }
    
    func setUIEnabled(enabled: Bool){
        if enabled{
            urlTextField.enabled = enabled
            submitButton.enabled = enabled
        }else{
            urlTextField.enabled = enabled
            submitButton.enabled = enabled
        }
    }
}