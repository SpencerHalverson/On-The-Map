//
//  StudentInformation.swift
//  On The Map
//
//  Created by Spencer Halverson on 4/23/16.
//  Copyright © 2016 Bodypursuit.com. All rights reserved.
//

import Foundation
import UIKit

struct StudentInformation {
    var firstName: String?
    var lastName: String?
    var mediaUrl: String?
    var lat: Double?
    var lon: Double?
    var studentDict: [String:AnyObject]?
    
    init(firstName: String, lastName: String, mediaUrl: String, lat: Double, lon: Double, studentDict: [String:AnyObject]?){
        self.firstName = firstName
        self.lastName = lastName
        self.mediaUrl = mediaUrl
        self.lat = lat
        self.lon = lon
        self.studentDict = studentDict
    }
}