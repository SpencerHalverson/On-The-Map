//
//  GCD.swift
//  On The Map
//
//  Created by Spencer Halverson on 4/23/16.
//  Copyright © 2016 Bodypursuit.com. All rights reserved.
//


import Foundation

func performUIUpdatesOnMain(updates: () -> Void) {
    dispatch_async(dispatch_get_main_queue()) {
        updates()
    }
}
