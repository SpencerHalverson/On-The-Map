//
//  LoginViewController.swift
//  On The Map
//
//  Created by Spencer Halverson on 4/22/16.
//  Copyright © 2016 Bodypursuit.com. All rights reserved.
//

import UIKit
import SafariServices

class LoginViewController: UIViewController, SFSafariViewControllerDelegate{
   
    var appDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
    
    @IBOutlet weak var loadingIndicator: UIActivityIndicatorView!
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var loginButton: UIButton!
    @IBOutlet weak var facebookButton: UIButton!
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        setUIEnabled(true)
        facebookButton.alpha = 0.5
    }
    @IBAction func hideEmailkeyboard(sender: UITextField) {
        sender.resignFirstResponder()
    }
    @IBAction func hidePasswordKeyboard(sender: UITextField) {
        sender.resignFirstResponder()
    }

    @IBAction func login(sender: UIButton) {
        
        passwordTextField.resignFirstResponder()
        setUIEnabled(false)
        
        if emailTextField.text!.isEmpty || passwordTextField.text!.isEmpty {
            let message = "Enter a valid username or password."
            displayTextFieldAlert(message)
        } else {
            UdacityApiMethods.login(emailTextField.text!, password: passwordTextField.text!) {(success, errorString) in
                performUIUpdatesOnMain(){
                    if success{
                        self.presentMapView()
                        self.setUIEnabled(true)
                    }else{
                        self.displayTextFieldAlert(errorString!)
                    }
                }
            }            
        }
        
    }
    
    func presentMapView(){
        let controller = self.storyboard!.instantiateViewControllerWithIdentifier("NavigationController") as! UINavigationController
        self.presentViewController(controller, animated: true) {(completion) in
            self.setUIEnabled(true)
        }
    }

    @IBAction func signUpForAccount(sender: UIButton) {
        let url = NSURL(string: "https://www.udacity.com/account/auth#!/signup")
        let safariVC = SFSafariViewController(URL: url!)
        safariVC.delegate = self
        self.presentViewController(safariVC, animated: true, completion: nil)
    }
    
}

extension LoginViewController {
    
    func setUIEnabled(enabled: Bool){
        emailTextField.enabled = enabled
        passwordTextField.enabled = enabled
        loginButton.enabled = enabled
        facebookButton.enabled = enabled
        
        if enabled {
            loadingIndicator.hidesWhenStopped = true
            loadingIndicator.stopAnimating()
            loginButton.alpha = 1.0
            loginButton.alpha = 1.0
        } else {
            loadingIndicator.hidden = false
            loadingIndicator.startAnimating()
            loginButton.alpha = 0.5
            facebookButton.alpha = 0.5
        }
    }
    
    func displayTextFieldAlert(message: String) {
        
        let alertVC = UIAlertController.init(title: "Login Failed", message: message, preferredStyle: UIAlertControllerStyle.Alert)
        let okAction = UIAlertAction(title: "Try Again", style: .Cancel) {(action) in
            self.setUIEnabled(true)
        }
        alertVC.addAction(okAction)
        presentViewController(alertVC, animated: true, completion: nil)
        
    }

}
