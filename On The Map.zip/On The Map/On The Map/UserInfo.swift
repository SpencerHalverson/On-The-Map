//
//  UserInfo.swift
//  On The Map
//
//  Created by Spencer Halverson on 4/25/16.
//  Copyright © 2016 Bodypursuit.com. All rights reserved.
//

import Foundation
import UIKit

struct UserInfo {
    var firstName: String?
    var lastName: String?
    
    init(firstName: String, lastName: String){
        self.firstName = firstName
        self.lastName = lastName
    }
}