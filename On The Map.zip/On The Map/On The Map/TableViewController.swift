//
//  TableViewController.swift
//  On The Map
//
//  Created by Spencer Halverson on 4/22/16.
//  Copyright © 2016 Bodypursuit.com. All rights reserved.
//

import Foundation
import UIKit
import CoreLocation
import SafariServices

class TableViewController: UITableViewController, SFSafariViewControllerDelegate {
    
    var appDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        
        parentViewController!.navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .Refresh, target: self, action: "refreshTable")
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        tableView.reloadData()
    }
    
    func refreshTable(){
        Students.studentsArray.removeAll()
        Students.annotationsArray.removeAll()
        
        ParseApiMethods.getStudents() {(success, studentInfo, errorString) in
            performUIUpdatesOnMain(){
                if success{
                    self.tableView.reloadData()
                }else{
                    self.displayAlert(errorString!)
                }
            }
        }
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Students.studentsArray.count
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let student = Students.studentsArray[indexPath.row]
        let cell = tableView.dequeueReusableCellWithIdentifier("StudentCell", forIndexPath: indexPath)
        if let first = student.firstName, let last = student.lastName, let url = student.mediaUrl{
            cell.textLabel?.text = first + " " + last
            cell.detailTextLabel?.text = url
        }
        return cell
    }
    
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        let student = Students.studentsArray[indexPath.row]
        if let urlString = student.mediaUrl{
            if let url = NSURL(string: urlString){
                if UIApplication.sharedApplication().canOpenURL(url){
                    let safariVC = SFSafariViewController(URL: url)
                    safariVC.delegate = self
                    presentViewController(safariVC, animated: true, completion: nil)
                }else{
                    displayAlert("Invalid URL")
                }
            }else{
                displayAlert("Invalid URL")
            }
        }
    }
    
    func displayAlert(message: String){
        let alertVC = UIAlertController.init(title: "Safari Failed", message: message, preferredStyle: UIAlertControllerStyle.Alert)
        let okAction = UIAlertAction(title: "Try Again", style: .Cancel) {(action) in
        }
        alertVC.addAction(okAction)
        presentViewController(alertVC, animated: true, completion: nil)
    }

    
}