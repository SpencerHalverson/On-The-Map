//
//  Students.swift
//  On The Map
//
//  Created by Spencer Halverson on 4/26/16.
//  Copyright © 2016 Bodypursuit.com. All rights reserved.
//

import Foundation
import UIKit
import MapKit

struct Students {
    
    static var studentsArray = [StudentInformation]()
    
    static var annotationsArray = [MKAnnotation]()
}